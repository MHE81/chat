module AP.Project {
    requires javafx.fxml;
    requires javafx.controls;
    opens Main;
}