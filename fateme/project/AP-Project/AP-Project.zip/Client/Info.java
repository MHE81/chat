package Main;

import java.util.ArrayList;

public class Info {
    ArrayList<String> letters = new ArrayList<>();
    public Info(){
        letters.add("آ");
        letters.add("ب");
        letters.add("پ");
        letters.add("ت");
        letters.add("س");
        letters.add("ج");
        letters.add("چ");
        letters.add("ح");
        letters.add("خ");
        letters.add("د");
        letters.add("ذ");
        letters.add("ر");
        letters.add("ز");
        letters.add("ژ");
        letters.add("س");
        letters.add("ش");
        letters.add("ص");
        letters.add("ض");
        letters.add("ط");
        letters.add("ظ");
        letters.add("ع");
        letters.add("غ");
        letters.add("ف");
        letters.add("ق");
        letters.add("ک");
        letters.add("گ");
        letters.add("ل");
        letters.add("م");
        letters.add("ن");
        letters.add("و");
        letters.add("ه");
        letters.add("ی");
    }
}
